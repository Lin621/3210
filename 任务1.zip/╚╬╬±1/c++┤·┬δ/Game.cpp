#include "Game.h"
Game::Game(void)
{
	for (int i = 0; i<9; i++)
	{
		qipan[i] = '*';
	}
	count = 0;
	flag = 0;
}
void Game::display1()
{
	cout << "-----------" << endl;
	cout << "  " << qipan[0] << "  " << qipan[1] << "  " << qipan[2] << "  " << endl;
	cout << "-----------" << endl;
	cout << "  " << qipan[3] << "  " << qipan[4] << "  " << qipan[5] << "  " << endl;
	cout << "-----------" << endl;
	cout << "  " << qipan[6] << "  " << qipan[7] << "  " << qipan[8] << "  " << endl;
	cout << "-----------" << endl;
}
int Game::L_score(int i, int j)
{
	int score = 0;
	if (qipan[i - 1] == 'X' && qipan[j - 1] == 'X')
		score = 50;
	if (qipan[i - 1] == 'O' && qipan[j - 1] == 'O')
		score = 25;
	if (qipan[i - 1] == 'X' && qipan[j - 1] == '*')
		score = 10;
	if (qipan[i - 1] == 'O' && qipan[j - 1] == '*')
		score = 8;
	if (qipan[i - 1] == '*' && qipan[j - 1] == '*')
		score = 4;
	return score;
}
bool Game::judgeX(int i, int j, int k)
{
	bool F = false;
	if (qipan[i - 1] == 'X' && qipan[j - 1] == 'X' && qipan[k - 1] == 'X')
		F = true;
	return F;
}
bool Game::judgeO(int i, int j, int k)
{
	bool F = false;
	if (qipan[i - 1] == 'O' && qipan[j - 1] == 'O' && qipan[k - 1] == 'O')
		F = true;
	return F;
}
void Game::play2()
{
	int n = 0;
	int max = 0, temp = 0;
	int choose2;
	cout << "��ѡ������" << endl;
	cout << "1��X" << endl;
	cout << "2��O" << endl;
	cin >> choose2;
	if (choose2 == 1)
	{
		qipan[4] = 'O';
		count++;
		cout << "���Գ���:5λ��" << endl;
		display1();
		while (count < 9 && flag <= 1)
		{
			while (qipan[n - 1] != '*')
			{
				display1();
				cout << "����ҳ��壺" << endl;
				cin >> n;
				if (qipan[n - 1] == 'X' || qipan[n - 1] == 'O')
				{
					cout << "��λ�ò�Ϊ�գ������£�" << endl; cin >> n;
				}
			}
			qipan[n - 1] = 'X';
			count++;
			display1();
			if (judgeX(1, 2, 3) || judgeX(4, 5, 6) || judgeX(7, 8, 9) || judgeX(1, 4, 7) || judgeX(2, 5, 8) || judgeX(3, 6, 9) || judgeX(1, 5, 9) || judgeX(3, 5, 7))
			{
				flag = 1;//��һ�ʤ
				break;
			}
			if ((count < 9) && (flag < 1))
			{

				for (int k = 0; k<9; k++)
				{
					if (qipan[k] == '*')
					{
						switch (k)
						{
						case 0:score[0] = L_score(2, 3) + L_score(4, 7) + L_score(5, 9);  break;
						case 1:score[1] = L_score(1, 3) + L_score(5, 8); break;
						case 2:score[2] = L_score(1, 2) + L_score(5, 7) + L_score(6, 9); break;
						case 3:score[3] = L_score(1, 7) + L_score(5, 6); break;
						case 4:score[4] = L_score(2, 8) + L_score(4, 6) + L_score(1, 9) + L_score(3, 7); break;
						case 5:score[5] = L_score(3, 9) + L_score(4, 5); break;
						case 6:score[6] = L_score(1, 4) + L_score(8, 9) + L_score(3, 5); break;
						case 7:score[7] = L_score(2, 5) + L_score(7, 9); break;
						case 8:score[8] = L_score(1, 5) + L_score(3, 6) + L_score(7, 8); break;
						}
					}
					else
						score[k] = -1;

					max = score[0];
					for (int k = 1; k < 9; k++)

					if (max < score[k])
					{
						max = score[k];
						temp = k;
					}
				}
				qipan[temp] = 'O';
				count++;
				cout << "���Գ���" << temp + 1 << "λ��" << endl;
				display1();
				if (judgeO(1, 2, 3) || judgeO(4, 5, 6) || judgeO(7, 8, 9) || judgeO(1, 4, 7) || judgeO(2, 5, 8) || judgeO(3, 6, 9) || judgeO(1, 5, 9) || judgeO(3, 5, 7))
				{
					flag = 2;//���Ի�ʤ
					break;
				}
			}
		}
		if (flag == 0)cout << "ƽ�֣�" << endl;
		else if (flag == 1) cout << "��һ�ʤ��" << endl;
		else cout << "���Ի�ʤ��" << endl;
	}
	if (choose2 == 2)
	{
		qipan[4] = 'X';
		count++;
		cout << "���Գ���:5λ��" << endl;
		display1();
		while (count < 9 && flag <= 1)
		{
			while (qipan[n - 1] != '*')
			{
				display1();
				cout << "����ҳ��壺" << endl;
				cin >> n;
				if (qipan[n - 1] == 'X' || qipan[n - 1] == 'O')
				{
					cout << "��λ�ò�Ϊ�գ������£�" << endl; cin >> n;
				}
			}

			qipan[n - 1] = 'O';
			count++;
			display1();
			if (judgeO(1, 2, 3) || judgeO(4, 5, 6) || judgeO(7, 8, 9) || judgeO(1, 4, 7) || judgeO(2, 5, 8) || judgeO(3, 6, 9) || judgeO(1, 5, 9) || judgeO(3, 5, 7))
			{
				flag = 1;//��һ�ʤ
				break;
			}
			if ((count < 9) && (flag < 1))
			{
				for (int k = 0; k < 9; k++)
				{
					if (qipan[k] == '*')
					{
						switch (k)
						{
						case 0:score[0] = L_score(2, 3) + L_score(4, 7) + L_score(5, 9);  break;
						case 1:score[1] = L_score(1, 3) + L_score(5, 8); break;
						case 2:score[2] = L_score(1, 2) + L_score(5, 7) + L_score(6, 9); break;
						case 3:score[3] = L_score(1, 7) + L_score(5, 6); break;
						case 4:score[4] = L_score(2, 8) + L_score(4, 6) + L_score(1, 9) + L_score(3, 7); break;
						case 5:score[5] = L_score(3, 9) + L_score(4, 5); break;
						case 6:score[6] = L_score(1, 4) + L_score(8, 9) + L_score(3, 5); break;
						case 7:score[7] = L_score(2, 5) + L_score(7, 9); break;
						case 8:score[8] = L_score(1, 5) + L_score(3, 6) + L_score(7, 8); break;
						}
					}
					else
						score[k] = -1;

					max = score[0];
					for (int k = 1; k < 9; k++)

					if (max < score[k])
					{
						max = score[k];
						temp = k;
					}
				}
				qipan[temp] = 'X';
				count++;
				cout << "���Գ���" << temp + 1 << "λ��" << endl;
				display1();
				if (judgeX(1, 2, 3) || judgeX(4, 5, 6) || judgeX(7, 8, 9) || judgeX(1, 4, 7) || judgeX(2, 5, 8) || judgeX(3, 6, 9) || judgeX(1, 5, 9) || judgeX(3, 5, 7))
				{
					flag = 2;//���Ի�ʤ
					break;
				}
			}
		}
		if (flag == 0)cout << "ƽ�֣�" << endl;
		else if (flag == 1) cout << "��һ�ʤ��" << endl;
		else cout << "���Ի�ʤ��" << endl;
	}
}
void Game::play1()
{
	int n = 0;
	int max = 0, temp = 0;

	int choose2;
	cout << "��ѡ������" << endl;
	cout << "1��X" << endl;
	cout << "2��O" << endl;
	cin >> choose2;

	if (choose2 == 1)
	{
		display1();
		cout << "����ҳ��壺" << endl;
		cin >> n;
		qipan[n - 1] = 'X';
		count++;
		display1();
		while (count < 9 && flag <= 1)
		{
			if ((count < 9) && (flag < 1))
			{

				for (int k = 0; k<9; k++)
				{
					if (qipan[k] == '*')
					{
						switch (k)
						{
						case 0:score[0] = L_score(2, 3) + L_score(4, 7) + L_score(5, 9);  break;
						case 1:score[1] = L_score(1, 3) + L_score(5, 8); break;
						case 2:score[2] = L_score(1, 2) + L_score(5, 7) + L_score(6, 9); break;
						case 3:score[3] = L_score(1, 7) + L_score(5, 6); break;
						case 4:score[4] = L_score(2, 8) + L_score(4, 6) + L_score(1, 9) + L_score(3, 7); break;
						case 5:score[5] = L_score(3, 9) + L_score(4, 5); break;
						case 6:score[6] = L_score(1, 4) + L_score(8, 9) + L_score(3, 5); break;
						case 7:score[7] = L_score(2, 5) + L_score(7, 9); break;
						case 8:score[8] = L_score(1, 5) + L_score(3, 6) + L_score(7, 8); break;
						}
					}
					else
						score[k] = -1;
					max = score[0];
					for (int k = 1; k < 9; k++)
					if (max < score[k])
					{
						max = score[k];
						temp = k;
					}
				}
				qipan[temp] = 'O';
				count++;
				cout << "���Գ���" << temp + 1 << "λ��" << endl;
				display1();
				if (judgeO(1, 2, 3) || judgeO(4, 5, 6) || judgeO(7, 8, 9) || judgeO(1, 4, 7) || judgeO(2, 5, 8) || judgeO(3, 6, 9) || judgeO(1, 5, 9) || judgeO(3, 5, 7))
				{
					flag = 2;//���Ի�ʤ
					break;
				}
			}
			while (qipan[n - 1] != '*')
			{
				cout << "����ҳ��壺" << endl;
				cin >> n;
				if (qipan[n - 1] == 'X' || qipan[n - 1] == 'O')
				{
					cout << "��λ�ò�Ϊ�գ������£�" << endl; cin >> n;
				}
			}
			qipan[n - 1] = 'X';
			count++;
			display1();
			if (judgeX(1, 2, 3) || judgeX(4, 5, 6) || judgeX(7, 8, 9) || judgeX(1, 4, 7) || judgeX(2, 5, 8) || judgeX(3, 6, 9) || judgeX(1, 5, 9) || judgeX(3, 5, 7))
			{
				flag = 1;//��һ�ʤ
				break;
			}
		}
		if (flag == 0)cout << "ƽ�֣�" << endl;
		else if (flag == 1) cout << "��һ�ʤ��" << endl;
		else cout << "���Ի�ʤ��" << endl;
	}
	if (choose2 == 2)
	{
		display1();
		cout << "����ҳ��壺" << endl;
		cin >> n;
		qipan[n - 1] = 'O';
		count++;
		display1();
		while (count < 9 && flag <= 1)
		{
			if ((count < 9) && (flag < 1))
			{
				for (int k = 0; k<9; k++)
				{
					if (qipan[k] == '*')
					{
						switch (k)
						{
						case 0:score[0] = L_score(2, 3) + L_score(4, 7) + L_score(5, 9);  break;
						case 1:score[1] = L_score(1, 3) + L_score(5, 8); break;
						case 2:score[2] = L_score(1, 2) + L_score(5, 7) + L_score(6, 9); break;
						case 3:score[3] = L_score(1, 7) + L_score(5, 6); break;
						case 4:score[4] = L_score(2, 8) + L_score(4, 6) + L_score(1, 9) + L_score(3, 7); break;
						case 5:score[5] = L_score(3, 9) + L_score(4, 5); break;
						case 6:score[6] = L_score(1, 4) + L_score(8, 9) + L_score(3, 5); break;
						case 7:score[7] = L_score(2, 5) + L_score(7, 9); break;
						case 8:score[8] = L_score(1, 5) + L_score(3, 6) + L_score(7, 8); break;
						}
					}
					else
						score[k] = -1;
					max = score[0];
					for (int k = 1; k < 9; k++)

					if (max < score[k])
					{
						max = score[k];
						temp = k;
					}
				}
				qipan[temp] = 'X';
				count++;
				cout << "���Գ���" << temp + 1 << "λ��" << endl;
				display1();
				if (judgeX(1, 2, 3) || judgeX(4, 5, 6) || judgeX(7, 8, 9) || judgeX(1, 4, 7) || judgeX(2, 5, 8) || judgeX(3, 6, 9) || judgeX(1, 5, 9) || judgeX(3, 5, 7))
				{
					flag = 2;//���Ի�ʤ
					break;
				}
			}
			while (qipan[n - 1] != '*')
			{
				cout << "����ҳ��壺" << endl;
				cin >> n;
				if (qipan[n - 1] == 'X' || qipan[n - 1] == 'O')
				{
					cout << "��λ�ò�Ϊ�գ������£�" << endl; cin >> n;
				}
			}
			qipan[n - 1] = 'O';
			count++;
			display1();
			if (judgeO(1, 2, 3) || judgeO(4, 5, 6) || judgeO(7, 8, 9) || judgeO(1, 4, 7) || judgeO(2, 5, 8) || judgeO(3, 6, 9) || judgeO(1, 5, 9) || judgeO(3, 5, 7))
			{
				flag = 1;//��һ�ʤ
				break;
			}
		}
		if (flag == 0)cout << "ƽ�֣�" << endl;
		else if (flag == 1) cout << "��һ�ʤ��" << endl;
		else cout << "���Ի�ʤ��" << endl;
	}
}